require('../models/database');
const Category = require('../models/Category');
const Car = require('../models/Cars');

/**
 * GET /
 * Homepage 
*/
exports.homepage = async(req, res) => {
  try {
    const limitNumber = 5;
    const categories = await Category.find({}).limit(limitNumber);
    const latest = await Car.find({}).sort({_id: -1}).limit(limitNumber);
    const Sedan = await Car.find({ 'category': 'Sedan' }).limit(limitNumber);
    const ElectricCar = await Car.find({ 'category': 'ElectricCar' }).limit(limitNumber);
    const SportsCar = await Car.find({ 'category': 'SportsCar' }).limit(limitNumber);

    const car = { latest, Sedan, ElectricCar, SportsCar };

    res.render('index', { title: 'Cooking Blog - Home', categories, car } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
}

/**
 * GET /categories
 * Categories 
*/
exports.exploreCategories = async(req, res) => {
  try {
    const limitNumber = 20;
    const categories = await Category.find({}).limit(limitNumber);
    res.render('categories', { title: 'Cooking Blog - Categoreis', categories } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 


/**
 * GET /categories/:id
 * Categories By Id
*/
exports.exploreCategoriesById = async(req, res) => { 
  try {
    let categoryId = req.params.id;
    const limitNumber = 20;
    const categoryById = await Car.find({ 'category': categoryId }).limit(limitNumber);
    res.render('categories', { title: 'Cooking Blog - Categoreis', categoryById } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 
 
/**
 * GET /Car/:id
 * Car 
*/
exports.exploreCar = async(req, res) => {
  try {
    let carId = req.params.id;
    const car = await Car.findById(carId);
    res.render('car', { title: 'Cooking Blog - Car', car } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 


/**
 * POST /search
 * Search 
*/
exports.searchCar = async(req, res) => {
  try {
    let searchTerm = req.body.searchTerm;
    let car = await Car.find( { $text: { $search: searchTerm, $diacriticSensitive: true } });
    res.render('search', { title: 'Cooking Blog - Search', car } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
  
}

/**
 * GET /explore-latest
 * Explplore Latest 
*/
exports.exploreLatest = async(req, res) => {
  try {
    const limitNumber = 20;
    const car = await Car.find({}).sort({ _id: -1 }).limit(limitNumber);
    res.render('explore-latest', { title: 'Cooking Blog - Explore Latest', car } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 



/**
 * GET /explore-random
 * Explore Random as JSON
*/
exports.exploreRandom = async(req, res) => {
  try {
    let count = await Car.find().countDocuments();
    let random = Math.floor(Math.random() * count);
    let car = await Car.findOne().skip(random).exec();
    res.render('explore-random', { title: 'Cooking Blog - Explore Latest', car } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 


/**
 * GET /submit-car
 * Submit Car
*/
exports.submitCar = async(req, res) => {
  const infoErrorsObj = req.flash('infoErrors');
  const infoSubmitObj = req.flash('infoSubmit');
  res.render('submit-car', { title: 'Cooking Blog - Submit Car', infoErrorsObj, infoSubmitObj  } );
}

/**
 * POST /submit-car
 * Submit Car
*/
exports.submitCarOnPost = async(req, res) => {
  try {

    let imageUploadFile;
    let uploadPath;
    let newImageName;

    if(!req.files || Object.keys(req.files).length === 0){
      console.log('No Files where uploaded.');
    } else {

      imageUploadFile = req.files.image;
      newImageName = Date.now() + imageUploadFile.name;

      uploadPath = require('path').resolve('./') + '/public/uploads/' + newImageName;

      imageUploadFile.mv(uploadPath, function(err){
        if(err) return res.satus(500).send(err);
      })

    }

    const newCar = new Car({
      name: req.body.name,
      description: req.body.description,
      email: req.body.email,
      ingredients: req.body.ingredients,
      category: req.body.category,
      image: newImageName
    });
    
    await newCar.save();

    req.flash('infoSubmit', 'Car has been added.')
    res.redirect('/submit-car');
  } catch (error) {
    // res.json(error);
    req.flash('infoErrors', error);
    res.redirect('/submit-car');
  }
}




// Delete Car
// async function deleteCar(){
//   try {
//     await Car.deleteOne({ name: 'Moto' });
//   } catch (error) {
//     console.log(error);
//   }
// }
// deleteCar();


// Update Car
// async function updateCar(){
//   try {
//     const res = await Car.updateOne({ name: 'New Car' }, { name: 'New Car Updated' });
//     res.n; // Number of documents matched
//     res.nModified; // Number of documents modified
//   } catch (error) {
//     console.log(error);
//   }
// }
// updateCar();






/**
 * Dummy Data Example
*/

// async function insertDymmyCategoryData(){
//   try {
//     await Category.insertMany([
//       {
//         "name": "Sedan",
//         "image": "Sedan.jpg"
//       },
//       {
//         "name": "ElectricCar",
//         "image": "Tesla.webp"
//       }, 
//       {
//         "name": "SportsCar",
//         "image": "MG.jpg"
//       },
      // {
      //   "name": "SUV",
      //   "image": "Vigo.jpg"
      // }, 
//       {
//         "name": "UpComingCars",
//         "image": "Cyber.jpg"
//       },
//     ]);
//   } catch (error) {
//     console.log('err', + error)
//   }
// }

// insertDymmyCategoryData();


// async function insertDymmyCarsData(){
//   try {
//     await Cars.insertMany([
//       { 
//         "name": "Toyota COROLLA 2022 ",
//         "description": `The brand new Hilux-E is an ultimate beast. Be it the hustle and bustle of urban territory or the extreme off road conditions Hilux-E is your optimum drive personified.`,
//         "email": "Carsemail@raddy.co.uk",
//         "Specifications": [
//           "Keyless entry",
//           "Base variant comes standard with air conditioning, an infotainment system, power steering, an Eco meter, and a tachometer",
//           "VN Turbo",
//         ],
//         "category": "Sedan", 
//         "image": "Sedan.jpg"
//       },
//       { 
//         "name": "Cyber Truck",
//         "description": `The exterior design exudes a compelling sense of authority, thanks to its sheer size. Its imposing surfaces extend from the upright front end into the visually powerful rear and underscore the feeling of luxury.`,
//         "email": "Carsemail@raddy.co.uk",
//         "Specifications": [
//           "BMW CRYSTAL HEADLIGHT ICONIC GLOW.",
//           "A NEW DIMENSION IN LUXURY.",
//           "MODERN DRIVING SPACE.",
//         ],
//         "category": "UpComingCars", 
//         "image": "Cyber.jpg"
//       },
//     ]);
//   } catch (error) {
//     console.log('err', + error)
//   }
// }

// insertDymmyCarsData();



