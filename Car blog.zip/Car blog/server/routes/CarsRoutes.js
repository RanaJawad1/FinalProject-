const express = require('express');
const router = express.Router();
const CarsController = require('../controllers/CarsController');

/**
 * App Routes 
*/
router.get('/', CarsController.homepage);
router.get('/Cars/:id', CarsController.exploreCar);
router.get('/categories', CarsController.exploreCategories);
router.get('/categories/:id', CarsController.exploreCategoriesById);
router.post('/search', CarsController.searchCar);
router.get('/explore-latest', CarsController.exploreLatest);
router.get('/explore-random', CarsController.exploreRandom);
router.get('/submit-car', CarsController.submitCar);
router.post('/submit-car', CarsController.submitCarOnPost);

 
module.exports = router;