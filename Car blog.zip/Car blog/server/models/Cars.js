const mongoose = require('mongoose');

const CarsSchema = new mongoose.Schema({
  name: {
    type: String,
    required: 'This field is required.'
  },
  description: {
    type: String,
    required: 'This field is required.'
  },
  email: {
    type: String,
    required: 'This field is required.'
  },
  Specifications: {
    type: Array,
    required: 'This field is required.'
  },
  category: {
    type: String,
    enum: ['Sedan', 'ElectricCar', 'SportsCar', 'UpComingCars', 'Indian'],
    required: 'This field is required.'
  },
  image: {
    type: String,
    required: 'This field is required.'
  },
});

CarsSchema.index({ name: 'text', description: 'text' });

// WildCard Indexing
//CarsSchema.index({ "$**" : 'text' });

module.exports = mongoose.model('Cars', CarsSchema);