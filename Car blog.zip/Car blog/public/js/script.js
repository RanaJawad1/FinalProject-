let addSpecificationsBtn = document.getElementById('addSpecificationsBtn');
let specList = document.querySelector('.specList');
let specDiv = document.querySelectorAll('.specDiv')[0];

addSpecificationsBtn.addEventListener('click', function(){
  let newSpecifications = specDiv.cloneNode(true);
  let input = newSpecifications.getElementsByTagName('input')[0];
  input.value = '';
  specList.appendChild(newSpecifications);
});